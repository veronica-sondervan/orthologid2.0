#!/bin/bash
#echo arg $@
JOBID=$(qsub $@ )
#qsub $@
RC=$?
echo $JOBID
#echo $RC
echo $@ >>bigmon.log
exit 0
#exit qsub $@
