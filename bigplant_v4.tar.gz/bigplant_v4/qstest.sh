#!/bin/ksh 
#
# mod to run blastp+ by chuck zegar 10/2/2015
# My PBS queue
PBSQ="cgsb-s"
arg1=${1:-1};
print "called with $arg1"
# Memory size of higher memory node needed for running mcl
HIMEM="12GB"
export OID_USER_DIR=`pwd`
export OID_HOME="/home/cmz209/orthotnt/OID_nw3"


# Check environment variables and user directory
if ! env | grep -q "^OID_HOME="; then
	print -u2 "OID_HOME not defined ... exiting"
	exit 1
fi

# Get version
if [[ -f $OID_HOME/mainline/VERSION ]]; then
	OID_VERSION=$(<$OID_HOME/mainline/VERSION)
else
	OID_VERSION="unknown"
fi

OID_BIN=$OID_HOME/bin

if [[ ! -d $OID_USER_DIR ]]; then
	print -u2 "OID_USER_DIR \"$OID_USER_DIR\" is not a directory"
	exit 1
fi

# Use dir name as run name
OID_RUN=$(basename $OID_USER_DIR)

print "== Starting OrthologID version $OID_VERSION pipeline =="
print "Run directory is $OID_USER_DIR"

# Check/parse config file
CONFIG=$OID_USER_DIR/config
if [[ ! -f $CONFIG ]]; then
	print -u2 "Config file does not exist ... exiting"
	exit 1
fi
set -A INGROUP $(grep INGROUP $CONFIG | cut -f2 -d=)
set -A OUTGROUP $(grep OUTGROUP $CONFIG | cut -f2 -d=)
NCPU=$(sed -n 's/^NCPU *= *\([0-9]*\).*/\1/p' $CONFIG)
if [[ -z $NCPU ]]; then
	NCPU=1
fi

print "ncp set $NCPU"
TCPU=$NCPU
JOB_SCRIPT=$OID_USER_DIR/run_test.sh
cat <<EOF >$JOB_SCRIPT
#!/bin/sh
#
# PBS job script for test blast
#

#PBS -S /bin/bash
#PBS -j oe
#PBS -o /scratch/cmz209/orthotnt/oidTest9/
#PBS -q $PBSQ
#PBS -l mem=$HIMEM
#PBS -l walltime=12:00:00
#PBS -N $OID_RUN
#PBS -V 

PATH=$OID_BIN:$PATH

cd \$OID_USER_DIR
#test.pl
$OID_HOME/bin/mk_blast_parts.pl $arg1

EOF
# End job script
chmod a+x $JOB_SCRIPT
print "$JOB_SCRIPT has $NCPU"
            qsub -l nodes=1:ppn=$TCPU $JOB_SCRIPT;
