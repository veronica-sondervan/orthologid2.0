#!/bin/ksh
export OID_USER_DIR=`pwd`
export OID_HOME=~/orthotnt/OID_nw3
$OID_HOME/bin/rdfamdb.pl
#
rm schedone
while [[ ! -f schedone ]]; do
$OID_HOME/bin/orthologid.pl -s 'hello'
if [[ ! -f schedone ]]; then
   print "orthologid.pl -s aborted before finish"
   date
fi
done;
date
time
