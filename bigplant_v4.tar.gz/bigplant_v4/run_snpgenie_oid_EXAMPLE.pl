#! /share/apps/perl/5.24.0/intel/bin/perl 

#AMNH-HUXLEY-PBS is #! /usr/local/software/PERL/perl-5.26.0/bin/perl
#NYU-PRINCE-SLURM is #! /share/apps/perl/5.24.0/intel/bin/perl 
#PC is #! /usr/bin/perl

#my $family_id = 1;

# PROGRAM: SNPGenie NGS Nei-Gojobori algorithm adapted for OrthologID and HPC

# Copyright (C) 2017 Chase W. Nelson

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# DATE CREATED: January 18, 2017
# AUTHOR: Chase W. Nelson
# CONTACT1: cnelson@amnh.org
# CONTACT2: cwnelson88@gmail.com
# AFFILIATION1: Sackler Institute for Comparative Genomics, American Museum of Natural
#     History, New York, NY 10024, USA
# AFFILIATION2: Special Volunteer, Division of Cancer Epidemiology & Genetics, National
#     Cancer Institute, National Institutes of Health, Rockville, MD 20850, USA
# AFFILIATION3: BigPlant Consortium, Center for Genomics and Systems Biology, New York 
#     University, New York, NY 10003, USA
# CITATION1: Nelson CW, Moncla LH, Hughes AL (2015) SNPGenie: estimating evolutionary 
#	parameters to detect natural selection using pooled next-generation sequencing data. 
#	Bioinformatics 31(22):3709-11, doi: 10.1093/bioinformatics/btv449.
# CITATION2: Nelson CW, Hughes AL (2015) Within-host nucleotide diversity of virus 
#	populations: Insights from next-generation sequencing. Infection, Genetics and 
#	Evolution 30:1-7, doi: 10.1016/j.meegid.2014.11.026

# ARGUMENTS:
#	[0] future development; optional; a NUMBER OF BOOTSTRAPS.

use strict;
#use warnings;
use Data::Dumper;
use Getopt::Long;
#use Getopt::Std;
#use Parallel::ForkManager;


# Make sure we have (and store) the environment variables
my ($OID_HOME, $OID_USER_DIR);
BEGIN {
	$OID_HOME = $ENV{'OID_HOME'};
	die "Environment variable OID_HOME is not defined ... exiting.\n"
	  if !defined($OID_HOME);
	$OID_USER_DIR = $ENV{'OID_USER_DIR'};
	die "Environment variable OID_USER_DIR is not defined ... exiting.\n"
	  if !defined($OID_USER_DIR);
}

# Get the time
my $time1 = time;
my $local_time1 = localtime;

print "\nSNPGenie initiated at local time $local_time1\n";

#########################################################################################
# Options
my $system_type; #PC SLURM PBS
my $ignore_done_flag;
my $secs_to_wait;
my $procs_per_node;
my $num_bootstraps = 0;
my $sliding_window_size;

# Get user input, if given. If a Boolean argument is passed, its value is 1; else undef
GetOptions( "system_type=s" => \$system_type, # mandatory string parameter: PC SLURM PBS
			"ignore_done_flag" => \$ignore_done_flag, # optional Boolean; set to false if not given
			"secs_to_wait:i" => \$secs_to_wait, # optional integer parameter
			"procs_per_node:i" => \$procs_per_node, # optional integer parameter
			"num_bootstraps:i" => \$num_bootstraps,
			"sliding_window_size:i" => \$sliding_window_size) # optional integer parameter
			
			or die "\n## WARNING: Error in command line arguments. SNPGenie for OID terminated.\n\n";
			# N.B.: When an argument, e.g., sliding_window_size, is called only as a flag, its value is 0
			# When it is not called at all, it is null

# Initialize values
if(! $system_type) {
	 die "\n## WARNING: The --system_type option must be specified:\n".
		"## PC, PBS, or SLURM. SNPGenie for OID terminated.\n\n";
}

if(! $ignore_done_flag) {
	$ignore_done_flag = 0; # default is 0: re-do everything if flag absent
} else {
	$ignore_done_flag = 1;
}

#print "\ncurr secs_to_wait is $secs_to_wait\n";
if(! $secs_to_wait) {
	if($secs_to_wait != 0) {
		$secs_to_wait = 600; # DEFAULT is 600
	}
} elsif($secs_to_wait < 60) {
	die "\n## WARNING: The --secs_to_wait option must be an integer ≥60\n".
		"## SNPGenie for OID terminated.\n\n";
} # else leave as-is

if(! $procs_per_node) {
	if($procs_per_node != 0) {
		$procs_per_node = 1; # DEFAULT is 1
	}
} elsif($procs_per_node < 1) {
	die "\n## WARNING: The --procs_per_node option must be an integer ≥1\n".
		"## SNPGenie for OID terminated.\n\n";
} # else leave as-is

if(! $sliding_window_size) {
	if($sliding_window_size != 0) { # called as a flag, but given no value
		$sliding_window_size = 9; # default behavior: nonamer peptide
	}
} elsif($sliding_window_size < 2) {
	warn "\n## WARNING: The --sliding_window_size option must be an integer ≥2\n".
		"## No sliding window performed.\n\n";
}


# If wanted, remove prior results; only need to remove this file once
if($ignore_done_flag == 1) {
	unlink "$OID_USER_DIR/data/family_diversity_results.txt";
}

#########################################################################################
# GET ALL FAMILY DIRECTORIES (numbers only; no 'S')
chdir("$OID_USER_DIR\/data");
my @OID_USER_DIR_contents = glob "*";
#print "\nThe globbed things in $OID_USER_DIR\/data are: @files_in_OID_USER_DIR\n\n";
# Get rid of non-number things
my @OID_USER_DIR_contents_NUMERICAL;
foreach my $family_id (@OID_USER_DIR_contents) {
	#print "\nfamily_id is $family_id\n";
	if($family_id =~ /^\d/) { # only directory names beginning with numbers, please
		#print "\nfamily_id does not contain a letter\n";
		push(@OID_USER_DIR_contents_NUMERICAL, $family_id);
	}
}

@OID_USER_DIR_contents = @OID_USER_DIR_contents_NUMERICAL;

chdir("$OID_HOME\/bin");

#########################################################################################
foreach my $family_id (@OID_USER_DIR_contents) {
#	chdir("$OID_USER_DIR\/data\/$family_id");
	
	print "#######################################################################".
		"##################\nInitiating family $family_id analysis...\n";
	
	if($system_type eq 'PC') {
		if($ignore_done_flag == 1) {
#			unlink "$OID_USER_DIR/data/$family_id\/snpgenie_run.log";
#			`$OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag`;
#			`nohup $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1 &`;
			print "Calling: $OID_HOME\/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1\n";
			my $output = `$OID_HOME\/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1`;
			#nohup $OID_HOME/bin/run_pipeline.sh > run.log 2>&1 &
			print "$output";
		} else {
#			`$OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id`;
#			`nohup $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1 &`;
			print "Calling: $OID_HOME\/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1\n";
			my $output = `$OID_HOME\/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1`;
			print "$output";
		}
	} elsif($system_type eq 'PBS') {
		if($ignore_done_flag == 1) {
			# Let's change directory here and print output in the script call to a family-specific snpgenie_run.log #####
			chdir("$OID_USER_DIR\/data\/$family_id");
			
#			`qsub -V -N OID_FAM_$family_id -l ncpus=1,walltime=01:00:00 -M cwnelson88\@gmail.com -m abe -j oe -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1 > snpgenie_run.log`;
			`qsub -V -N SNPG_F$family_id -l ncpus=1,walltime=01:00:00 -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1 > snpgenie_run.log`;
		} else {
			chdir("$OID_USER_DIR\/data\/$family_id");
			
#			`qsub -V -N OID_FAM_$family_id -l ncpus=1,walltime=01:00:00 -M cwnelson88\@gmail.com -m abe -j oe -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1 snpgenie_run.log`;
			`qsub -V -N SNPG_F$family_id -l ncpus=1,walltime=01:00:00 -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1 snpgenie_run.log`;
		}
	} elsif($system_type eq 'SLURM') {
		if($ignore_done_flag == 1) {
			chdir("$OID_USER_DIR\/data\/$family_id");
#			`sbatch --verbose --job-name=SNPGenie_FAM_$family_id --output=SNPGenie_FAM_$family_id%j.out --error=SNPGenie_FAM_$family_id%j.err --time=5:00:00 --nodes=1 --mem=10GB --mail-type=END --mail-user=cwnelson88\@gmail.com -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1 > snpgenie_run.log`;
			`sbatch --verbose --job-name=SNPG_F$family_id\_ --output=SNPGenie_FAM_$family_id\_%j.out --error=SNPGenie_FAM_$family_id\_%j.err --time=5:00:00 --nodes=1 --mem=1GB -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag 2>&1 > SNPGenie_FAM_$family_id\_%j.log`;
		} else {
			chdir("$OID_USER_DIR\/data\/$family_id");
#			`sbatch --verbose --job-name=SNPGenie_FAM_$family_id --output=SNPGenie_FAM_$family_id%j.out --error=SNPGenie_FAM_$family_id%j.err --time=5:00:00 --nodes=1 --mem=5GB --mail-type=END --mail-user=cwnelson88\@gmail.com -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1 > snpgenie_run.log`;
			`sbatch --verbose --job-name=SNPG_F$family_id\_ --output=SNPGenie_FAM_$family_id\_%j.out --error=SNPGenie_FAM_$family_id\_%j.err --time=5:00:00 --nodes=1 --mem=1GB -- $OID_HOME/bin/snpgenie_oid_HPC.pl --family_directory=$family_id 2>&1 > SNPGenie_FAM_$family_id\_%j.log`;
		}
	}
	
#	`nohup perl snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag > $OID_USER_DIR/data/$family_id/run.log 2>&1 &`
#	`qsub -V -N OID_FAM_$family_id -l ncpus=1,walltime=1:00:00 -M cwnelson88\@gmail.com -m abe -j oe -- snpgenie_oid_HPC.pl --family_directory=$family_id --ignore_done_flag`
	
#	`qsub -V -N OID_FAM_$family_id -l ncpus=60,walltime=11:00:00 -M cwnelson88@gmail.com -m abe -j oe $OID_USER_DIR/data/$family_id/family_$family_id\_script.sh`
}


my $seen_unfinished_family = 1;

print "\n\nWaiting for all families to finish...\n\n";

#########################################################################################
# Wait for all families to finish
SWEEP_WAIT: while($seen_unfinished_family == 1) {
	print "Waiting $secs_to_wait seconds...\n";
	sleep($secs_to_wait); # sleep and check again
	
	$seen_unfinished_family = 0; # hope for the best but set back if not
	
	# Code to loop directories to see if all with FAMILY.aligned also have .done
	# If a family isn't done, set $seen_unfinished_family=1 and break out of search loop
	foreach my $family_id (@OID_USER_DIR_contents) {
		if(-f "$OID_USER_DIR/data/$family_id/FAMILY.aligned") {
			# set unfinished to 1 if there's no .done and no .ignore
			unless(-f "$OID_USER_DIR/data/$family_id/.snpgenie_done") {
				unless(-f "$OID_USER_DIR/data/$family_id/.snpgenie_ignore") {
					print "We've seen an unfinished family ($family_id). ";
					$seen_unfinished_family = 1;
					last;
				}
			}
		}
	}
	
	# Wait longer if we're unfinished
	if($seen_unfinished_family == 1) {
		next SWEEP_WAIT;
	} else { # $seen_unfinished_family remains 0
		last; # move on to sweep results
	}
	
}

#########################################################################################
# Sweep up results
&sweep_snpgenie_oid_results;

print "\n\n";

# Print a completion message to screen
&end_the_program;


#########################################################################################
#########################################################################################
####################################                 ####################################
####################################   SUBROUTINES   ####################################
####################################                 ####################################
#########################################################################################
#########################################################################################

#########################################################################################
# SWEEP UP RESULTS
sub sweep_snpgenie_oid_results {
	# PRINT family_diversity_results.txt HEADER, but not if already present
	unless(-f "$OID_USER_DIR/data/family_diversity_results.txt") { 
		open(OUTFILE,">>$OID_USER_DIR/data/family_diversity_results.txt");
		print OUTFILE "family\tpartition\tN_sites\tS_sites\tN_diffs\tS_diffs\tdN\tdS\tdN-dS\t".
			"dN\/dS";
			
		if($num_bootstraps > 1) {
			print OUTFILE "\tSE_dN-dS\tz_value\n";
		} else {
			print OUTFILE "\n";
		}
		close OUTFILE;
	}
	
	# Sweep sliding window results
	## ADD HERE A SLIDING WINDOW SWEEP! 
	
	# Sweep whole-family results
	open(OUTFILE,">>$OID_USER_DIR/data/family_diversity_results.txt");
	
	SWEEP: foreach my $family_id (@OID_USER_DIR_contents) {
		if(-f "$OID_USER_DIR/data/$family_id/temp\_family\_diversity\_results\_line.txt") { 
			open(FAMILY_SUM, "$OID_USER_DIR/data/$family_id/temp\_family\_diversity\_results\_line.txt") or 
				die "Could not open file $OID_USER_DIR/data/$family_id/temp\_family\_diversity\_results\_line.txt";
		
			while(<FAMILY_SUM>) {
				#chomp;
				print OUTFILE "$_";
			}
			
			close FAMILY_SUM;
			unlink "$OID_USER_DIR/data/$family_id/temp\_family\_diversity\_results\_line.txt";
		}
	}
	close OUTFILE;
}



# End the program by notifying the screen at command line
sub end_the_program {
	my $time2 = time;
	my $local_time2 = localtime;
	
	my $time_diff = ($time2 - $time1);
	my $time_diff_rounded = sprintf("%.2f",$time_diff);
	my $mins_elapsed = ($time_diff / 60);
	my $whole_mins_elapsed = int($mins_elapsed);
	my $whole_mins_in_secs = ($whole_mins_elapsed * 60);
	my $secs_remaining = ($time_diff - $whole_mins_in_secs);
	my $secs_remaining_rounded = sprintf("%.2f",$secs_remaining);
	
	print "SNPGenie completed at local time $local_time2. The process took $time_diff_rounded secs, i.e., ".
			"$whole_mins_elapsed mins and $secs_remaining_rounded secs\n";

	print "\n################################################################################".
		"\n##               SNPGenie for OrthologID completed successfully.              ##".
		"\n##        Please find results in the \/data\/ dir and subdirs (families).       ##\n".
		"################################################################################".
		"\n\n\n"; 
}
