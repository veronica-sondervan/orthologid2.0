#!/bin/bash

### convert matrix
perl nexus2tnt.pl -n matrix.nex -o OUTGROUP >matrix.tnt

### find and save optimal trees
tnt bground p mpt.proc

### jackknife
tnt bground p jac.proc

### pbs
mkdir pbs/
cp pbs.pl pbs/
cp matrix.tnt pbs/
cp mpt-naked.nel pbs/
cp mpt.tre pbs/
cd pbs/
perl pbs.pl -l pbs.log -m matrix.tnt -n mpt-naked.nel -t mpt.tre > pbs.csv

