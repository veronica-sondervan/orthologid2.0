#!/usr/bin/env python
# By Gil Eshel June 22 2017
# This script is for parsing the GO enrichment tables (currently taking the q-values and not the p-values - ask the group if to change that), the partition_annotation_with_pbs_cutoff_4.txt from the PBS_GO_Enrichment_GO_stats_script_new.R, and the mpt_nel_labeled_with_jac_support_values.tre (has the support value for each node label), and output the information for each node in a json format
# Assumes that all the enrichment tables and the partition_annotation_with_pbs.txt are in the working directory.
# Generates the bpPBS.json file with information for all the nodes (for nodes that where not calculated for PBS values, the 'ovrTerm' and 'genePartition' keys will have an empty list "[]")
# synopsis : parse_toPBS.py 
# We can change that the script will take arguments for the path to the GO enrichment tables and the partition_annotation_with_pbs.txt, and tree file, like:
# import sys
# change "for file in os.listdir('.'):" to "for file in os.listdir(sys.argv[1]):" 
# change "with open("partition_annotation_with_pbs_filtered.txt", 'r') as f:" to "with open(sys.argv[1], 'r') as f:"

import fnmatch, os, json

ovrTerm_list_of_list = [] # list that store all the ovrTerm of each node (each ovrTerm is a dictionary)
genePartition = [] # list to store pbs and model_gene_id values(as dictionaries) for each node
genePartition_list_of_list = [] # list that store all the genePartition of each node
node_enrichemnt_table_names_list = [] # generate a list which contains the names of the enrichment tables (of each node)
node_ids_with_pbs = [] # store a list of node ids ("N1", "N2" ...) # currenly only nodes with PBS calculation are stored - change that!!!
node_ids = [] # store a list of all node ids ("N1", "N2" ...) from the newich tree
node_support = [] # list to store the node support value of each node # currenly only nodes with PBS calculation are stored - change that!!!
type_analysis = "GO" # added to the ovrTerm dictionary...
node_json = {} # final dict to output

### parse the tree with both node ids and support values to get node_support and node_ids (all nodes including the ones without PBS calculations)
f=open("mpt_nel_labeled_with_jac_support_values.tre", 'r') # open the mpt_nel_labeled_with_jac_support_values tree file for reading
tree=f.read() # read the the tree into a string
f.close() # close the tree file
## I need to have for each node_ids_with_pbs a dictionary with a nodeSupport key and the node_support value as the value... - append this to the node_support list
## I need to find the ")N#:" character and to extract the value between the ":" characters 
## for each node_ids_with_pbs, find the index for the first and second ":" and extract the string that is between these to indices
nodes_info = tree.split(")")[1:] # split the tree string based on ")" to get a list with node_id:support_value:branch_length strings
for i in nodes_info:
	node_ids.append(i.split(":")[0])
	node_support.append(i.split(":")[1])
	

### parse GO enrichment tables:
for file in os.listdir('.'): # go through the files in the current working folder to find the enrichment tables
    if fnmatch.fnmatch(file, 'N*_all_enriched_terms_table.csv'):
        node_enrichemnt_table_names_list.append(file) # list of enrichment table file names (only nodes with pbs calculations...!)
        node_ids_with_pbs.append(file.split("_")[0]) # list of node ids with pbs calculations corresponding the the enrichment table names list order ...

for f in node_enrichemnt_table_names_list:
    with open(f, 'r') as d:
        next(d) # if I will not use the header line - remove it from the code!!!
        ovrTerm = list() # list to store GO enriched term results (as dictionaries) 
        for line in d:
            li=line.strip()
            pValue=li.split(",")[7]
            desc = li.split(",")[1]
            GOid = li.split(",")[0]
            ovrTerm_dict = {"pValue":pValue, "desc":desc, "id":GOid, "type":type_analysis}
            ovrTerm.append(ovrTerm_dict)
        ovrTerm_list_of_list.append(ovrTerm)
       

### parse partition_annotation_with_pbs_filtered table:
node_id_from_pbs_table =[] # record the node_id
pbs = [] # record the pbs value
mode_gene_id = [] # record the pbs value

with open("partition_annotation_with_pbs_filtered.txt", 'r') as f:
    next(f) # skip the header line...
    for line in f:
        li=line.strip() 
        if li.split("\t")[5]!="NA": # store only partitions with model species identifier
            node_id_from_pbs_table.append(li.split("\t")[3])
            pbs.append(li.split("\t")[2])
            mode_gene_id.append(li.split("\t")[5])

for i in range(0, len(node_ids_with_pbs)): # Generate the list of partition dictionaries (genePartition_list_of_list) 
    for j in range(0, len(node_id_from_pbs_table)):
        if node_ids_with_pbs[i]==node_id_from_pbs_table[j]:
            pbs_gene_id = {"pbs":pbs[j],"atOrtholog":mode_gene_id[j]}
            genePartition.append(pbs_gene_id)
            if i==len(node_ids_with_pbs)-1 and j==len(node_id_from_pbs_table)-1:
                genePartition_list_of_list.append(genePartition)
        else:
            if len(genePartition) != 0:
            	genePartition_list_of_list.append(genePartition)
            	genePartition = []


### Add empty lists to the genePartition_list_of_list and ovrTerm_list_of_list for nodes without PBS calculations (generate new lists in the length and order of the node_ids list):
genePartition_list_of_list_all_nodes = [] 
ovrTerm_list_of_list_all_nodes = [] 

for i in range(0, len(node_ids)):
	if node_ids[i] in node_ids_with_pbs: # check if the i item in node_ids exist in the node_ids_with_pbs list (the sub list...)
		j = node_ids_with_pbs.index(node_ids[i]) # if it does, get the index for its position on the node_ids_with_pbs list
		genePartition_list_of_list_all_nodes.append(genePartition_list_of_list[j]) # append the genePartition_list_of_list item for that node
		ovrTerm_list_of_list_all_nodes.append(ovrTerm_list_of_list[j]) # append the ovrTerm_list_of_list item for that node
	else:
		genePartition_list_of_list_all_nodes.append([])
		ovrTerm_list_of_list_all_nodes.append([])
		
### Create the json file		         
node_json = {}  # open a dictionary for the final json object
for i in range(0, len(node_ids)): # for each node generate a dictionary that contains the ovrTerm, the genePartition lists and the support value
    node = dict()
    node['ovrTerm'] = list()
    node['ovrTerm'] = ovrTerm_list_of_list_all_nodes[i]
    node['genePartition'] = list()
    node['genePartition'] = genePartition_list_of_list_all_nodes[i]
    node['nodeSupport'] = list()
    node['nodeSupport'] = node_support[i]
    json_object = json.dumps(node) 
    node_json[node_ids[i]] = json_object # add the json dump object for that node to the final node_json dictionary

json_string = str(node_json)
json_string = json_string.replace('\\',"") 
json_string = json_string.replace('""','"')
json_string = json_string.replace("'",'"')
json_string = json_string.replace('"{"','{"')
json_string = json_string.replace('}"','}')
json_string = json_string.replace(", ",",")
json_string = json_string.replace(": ",":")
json_string = json_string.replace('}]}"','}]}')
with open('bpPBS.json', 'w') as fp: # Write the final node_json dictionary to the bpPBS.json file
    fp.write(json_string)
          
