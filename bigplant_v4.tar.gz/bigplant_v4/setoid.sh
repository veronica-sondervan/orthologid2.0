#!/bin/ksh
export OID_USER_DIR=$PBS_O_WORKDIR
export OID_HOME=~/orthotnt/bigplant_v3
echo $OID_HOME
echo $OID_USER_DIR
