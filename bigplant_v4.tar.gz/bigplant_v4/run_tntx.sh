#!/bin/sh
#
# PBS job script for orthologid
#

#PBS -S /bin/bash
#PBS -j oe
##PBS -l mem=12GB
##PBS -o /scratch/cmz209/orthotnt/oidTest8/log/job
#PBS -q cgsb-s
#PBS -N oidTest8
#PBS -M cmz209@nyu.edu
#PBS -m abe
#PBS -V 



OID_DATA=$OID_USER_DIR/data
Fam="$arg1"
cd $OID_DATA/$Fam
$OID_HOME/bin/runtntx.pl "$arg2" "$arg3"
 

