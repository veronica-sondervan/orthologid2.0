#!/bin/ksh
MY_SHELL=$0  
export MY_SHELL
OID_USER_DIR=`pwd`
export OID_USER_DIR
cd $OID_USER_DIR;
qsub -V qsblast.pbs

