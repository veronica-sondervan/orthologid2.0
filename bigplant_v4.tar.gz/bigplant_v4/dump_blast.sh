#!/bin/ksh
export OID_USER_DIR=`pwd`
export OID_HOME=/home/cmz209/orthotnt/OID_nw2
# Memory size of higher memory node needed for running mcl
HIMEM="24G"

#export PATH=/Volumes/nyudocs/blast-2.2.26/bin:$PATH
export PATH=~/blastplus/bin:$PATH
# Check environment variables and user directory
if ! env | grep -q "^OID_HOME="; then
	print -u2 "OID_HOME not defined ... exiting"
	exit 1
fi


OID_BIN=$OID_HOME/bin

if [[ ! -d $OID_USER_DIR ]]; then
	print -u2 "OID_USER_DIR \"$OID_USER_DIR\" is not a directory"
	exit 1
fi

# Use dir name as run name
OID_RUN=$(basename $OID_USER_DIR)


# Check/parse config file
#CONFIG=$OID_USER_DIR/config
#if [[ ! -f $CONFIG ]]; then
#	print -u2 "Config file does not exist ... exiting"
#	exit 1
#fi
#set -A INGROUP $(grep INGROUP $CONFIG | cut -f2 -d=)
#set -A OUTGROUP $(grep OUTGROUP $CONFIG | cut -f2 -d=)
#NCPU=$(sed -n 's/^NCPU *= *\([0-9]*\).*/\1/p' $CONFIG)
#if [[ -z $NCPU ]]; then
#	NCPU=1
#fi

# Setup BLAST database
#print "Setting up BLAST database ..."
#if [[ ! -d $OID_USER_DIR/blastdb ]]; then
#	print -u2 "Sequence directory \"$OID_USER_DIR/blastdb\" does not exist ... exiting"
#	exit 1
#fi
#$OID_BIN/setup_blastdb.sh "${INGROUP[@]}" "${OUTGROUP[@]}"
#if [[ $? -ne 0 ]]; then
#	print -u2 "Unable to setup BLAST db ... exiting"
#	exit 1
#fi

# Create relevant directories
#if [[ ! -d $OID_USER_DIR/blast ]]; then
#	mkdir $OID_USER_DIR/blast
#fi
#if [[ ! -d $OID_USER_DIR/data ]]; then
#	mkdir $OID_USER_DIR/data
#fi
#if [[ ! -d $OID_USER_DIR/log/job ]]; then
#	mkdir -p $OID_USER_DIR/log/job
#fi

# Generate job script
#JOB_SCRIPT=$OID_USER_DIR/run_oid_job.sh
#cat <<EOF >$JOB_SCRIPT
#!/bin/ksh
#
# PBS job script for orthologid
#
#
#PBS -S /bin/bash
#PBS -j oe
#PBS -o /scratch/cmz209/orthotnt/oidTest9/log/job/
#PBS -q $PBSQ
#PBS -N $OID_RUN
#PBS -V 
#
#PATH=$OID_BIN:$PATH
#echo "$# are $1 and $2"
#arg1 = "$1"
#arg2 = "$2"
#echo "i am here"
#echo "$arg2"
#orthologid.pl "$arg1" "$arg2"
#
#if [[ "\$arg1" == "-b" ]]; then
#	touch blast/.\$arg2.done
#fi
#EOF
# End job script
#chmod a+x $JOB_SCRIPT
#
#	print "Merging BLAST data ..."
#    $OID_BIN/justbl.pl $1
#	$OID_BIN/orthologid.pl -B

