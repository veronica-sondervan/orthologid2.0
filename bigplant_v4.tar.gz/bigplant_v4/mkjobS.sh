#!/bin/bash
JOB_SCRIPT=${1:-1};
cat <<EOF >$JOB_SCRIPT
#!/bin/bash
#
# slurm job script for orthologid
#
#SBATCH -p serial
#SBATCH -n 1
#SBATCH -o log/job

export PATH=$OID_BIN:$PATH

cd \$OID_USER_DIR
date
time
orthologid.pl \$1 \$2
if [[ "\$1" == "-b" ]]; then
	touch blast/.\$2.done
fi
EOF
# End job script

