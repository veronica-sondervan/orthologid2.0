#!/bin/sh
#
# PBS job script for test blast
#

#PBS -S /bin/bash
#PBS -j oe
##PBS -o /scratch/cmz209/orthotnt/oidTest9/
#PBS -q cgsb-s
#PBS -l mem=12GB
#PBS -l walltime=12:00:00
#PBS -N testblast
#PBS -V 


cd $OID_USER_DIR
#test.pl
##/home/cmz209/orthotnt/OID_nw3/bin/mk_blast_parts.pl 2
$OID_HOME/bin/mk_blast_parts.pl 2

