# Gil Eshel, June 9, 2017
# Script to retrive species taxonomy and output it in a json format for PhyloBrowse
# # synopsis : Rscript get_taxonomy.R <species_name_file> <Organism domain(e.g. "plants", "viruses", etc.)>
# Outputs the taxonomy.json files (old and new formats)
#install.packages("taxize")
#install.packages("jsonlite")
library(taxize) # for taxonomy retrival
library(jsonlite) # to convert the taxonomy dataframe to a json format

### Inputs ###
args = commandArgs(TRUE)
species = read.delim(args[1], sep = "\t", header=FALSE) # if not numeric, this will be treated as the name of the species.txt file with the species lables and full names for taxonomy
if (args[2]=="plant" | args[2]=="Plant" | args[2]=="plants" | args[2]=="Plants") {domain = "plant"} else {domain = "non-plant"} # define domain either as plant or non-plant (if we find better taxonomy resurces for other domains we can add them here)

# Get PhyloGeneious environment variables
oid_home_path = Sys.getenv("OID_HOME") 
oid_user_dir_path = Sys.getenv("OID_USER_DIR")

### Taxonomy ###
genus = c() # for storing plant genera 
for(i in 1:length(species$V2)){
  species_string = species$V2[i] # a string with the species name
  species_list = strsplit(as.character(species_string), " ")[[1]] # it break the species name to a list
  genus[i] = species_list[1] # store the genus
}
taxo = data.frame(species$V2, genus) # start a dataframe with species and genus names and add more levels to it
if (domain == "plant") {
  classplant = read.csv(paste(oid_home_path,"/PostProcessing/Plant_classification.csv", sep = ""), header=TRUE) #  Input the Plant_classification.csv file from the bigplant_v4/PostProcessing/Plant_classification.csv "/Users/gileshel/Documents/NYU_postdoc/EvoNet_pipeline/Plant_classification.csv"
  taxo$Family = classplant$family[match(genus,classplant$genus)]   
  taxo$Order = classplant$order[match(genus,classplant$genus)]   
} else {
  taxize_family = tax_name(species$V2, get = "family", db = "ncbi") # get family name from the NCBI Taxonomy database using the R package taxize - it is not ideal as there are many species that are missing (return "NA"). Using the genus name instead is a risk, as e.g. the plant Tribulus eichlerianus can't be found in NCBI, and the genus Tribulus is both a plant genus (Eudicots) and a sea snails genus (Gastropod). The user carfully validate the classification output and manually add the missing family information 
  taxize_order = tax_name(species$V2, get = "order", db = "ncbi") # get order name from the NCBI Taxonomy database using the R package taxize
  taxo$Family = taxize_family$family
  taxo$Order = taxize_order$order
}

colnames(taxo) = c("Species","Genus", "Family", "Order")

### Save multiple taxonomy levels in json format (new format) ###
# generate the taxonomy.json file for PhyloBrowse
taxo_json_new = toJSON(taxo)
write(taxo_json_new, file = "taxonomy_new_format.json") # save into taxonomy.json file the new format (e.g. {"Species":"Physcomitrella patens","Genus":"Physcomitrella","Family":"Funariaceae","Order":"Funariales"})
### Save one taxonomy level in the old format (We can remove this once the new format is functioning) ###
taxo$Species = paste0('"', taxo$Species, '"') # add quotes to the names so it will be recognized as strings by PhyloBrowse
taxo$Family = paste0('"', taxo$Family, '"') # add quotes to the names so it will be recognized as strings by PhyloBrowse
taxo_json_start = "{" # the beginning of the json format
taxo_json_end = "}" # the end of the json format
taxo_row = c() # build a vector to store the species:family pairs
taxo_row = paste(taxo$Species, taxo$Family, sep=":") # store the species:family pairs
taxo_row_string = paste(taxo_row, collapse = ',') # collapse the vector into one string (comma-seperated)
taxo_json = paste(c(taxo_json_start,taxo_row_string,taxo_json_end), collapse = '') # build the json as one string
write(taxo_json, file = "taxonomy_old_format.json") # save into taxonomy.json file the old format (e.g. "Zea mays":"Poaceae","Arabidopsis thaliana":"Brassicaceae")
