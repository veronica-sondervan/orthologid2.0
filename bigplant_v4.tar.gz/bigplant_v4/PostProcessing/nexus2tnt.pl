#!/usr/bin/perl

############################### This program is free software; you can redistribute it and/or modify
############################### it under the terms of the GNU General Public License as published by
############################### the Free Software Foundation; either version 2 of the License, or
############################### (at your option) any later version.
############################### 
############################### This program is distributed in the hope that it will be useful,
############################### but WITHOUT ANY WARRANTY; without even the implied warranty of
############################### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
############################### GNU General Public License for more details.
############################### 
############################### You should have received a copy of the GNU General Public License
############################### along with this program; if not, write to the Free Software
############################### Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
###############################
###############################
###############################
############################### Copyright 2013 Damon P. Little

my $m = 0;
my $n = ();
my %o = ();
my $r = 0;
for(my $k = $#ARGV; $k >= 0; $k--){
	if($ARGV[$k] eq '-m'){
		$m = 1;
		next;
	}
	if($ARGV[$k] eq '-n'){
		if(-e $ARGV[$k+1]){
			$n = $ARGV[$k+1];
		}
		next;	
	}
	if($ARGV[$k] eq '-o'){
		$ARGV[$k+1] =~ tr/[A-Z][a-z][0-9]\_//cd;
		if(length($ARGV[$k+1])){
			$o{$ARGV[$k+1]} = 1;
		}
		next;	
	}
	if($ARGV[$k] eq '-r'){
		$r = 1;	
	}	
}

open(LOG, ">nexus2tnt.log");

if(length($n)){ 
	open(INFILE, $n) || die("Could not open infile $n!");
	open(OUTFILE, ">temporary-matrix-do-not-touch") || die('Could not open file: temporary-matrix-do-not-touch!');	
	
	
	
	############################### GLOBALS
	my $characters = 0;
	my $taxa = 0;
	my $maxStates = 0;
	my $buffer = (); 
	my $pnames;
	
	
	############################### READ NEXUS FILE AND WRITE TO TEMP FILE
	my $lines = ();
	my $partition = ();
	my $k = 0;
	my $part=1;
	while(my $line = <INFILE>){
		chomp($line);
		if(length($line)){		
			if($line eq ';'){
				last;
			}
			if(($line =~ m/^\[ OG/)){
				if(length($lines) && length($partition)){
					$buffer .= code($lines, $partition);
					if(length($buffer) > 10000){
						print(OUTFILE "$buffer");
						$buffer = ();
					}
				}
				$lines = ();
				$partition = $line;
				$partition =~ /Arath#(AT\dG\d+)/;
				$arath_gene = $1;
				print LOG "$arath_gene :"
			}
			else{
				$lines .= $line . "\n";
			}
		}
	}
	if(length($lines) && length($partition)){
		$buffer .= code($lines, $partition);
	}
	close(INFILE);
	print(OUTFILE "$buffer\n");
	close(OUTFILE);
	
	
	############################### READ TEMP FILE
	open(INFILE, 'temporary-matrix-do-not-touch') || die('Could not open temporary-matrix-do-not-touch!');
	if($m || $r){
		$maxStates = 16;
	}
	else {
		$maxStates = 32;
	}
	$buffer = "nstates $maxStates;\n";
	if(keys(%o)){
		$buffer .= "taxonomy=;\n";
	}
	#$buffer .= "/*\n";
	#my @partition_names = split /\n/, $pnames;
	#for (my $i=0;$i<=$#partition_names;$i++){
		#$buffer .= "Partition $i = ";
		#$buffer .= "$partition_names[$i] ;\n";
	#}
	#$buffer .= "*/\n";
	#$buffer .= "'converted from $n'\n";
	$buffer .= "silent = buffer ;\n";
	$buffer .= "xread\n";
	$buffer .= $characters . ' ' . ($taxa+1) . "\n";	
	while(my $line = <INFILE>){
		chomp($line);
		if(length($line)){
			$buffer .= $line . "\n";
		}
		if(length($buffer) > 10000){
			print("$buffer");
			$buffer = ();
		}
	}
	$buffer .= ";\ncc - .;\n";
	if(keys(%o)){
		$buffer .= "outgroup[OUTGROUP;\n";
	}
	print("$buffer\nproc/;\n");
	close(INFILE);
	open(PFILE, ">includedPartitions.2.txt");
	print(PFILE $pnames);
	close(PFILE);
	#unlink("temporary-matrix-do-not-touch");
	sub code {
		my @lines = split(/\n/, $_[0]);
		my $partition = $_[1];

		############################### MAKE MATRIX
		if($taxa && ($#lines != $taxa)){
			print(LOG "The number of taxa differs among partitions! Partition '$partition' has been omitted.\n");
			return();
		}
		$taxa = $#lines;
		my $matrix = ();
		$matrix->[0][0] = ();
		my $chars = ();
		for(my $k = $#lines; $k >= 0; $k--){
			$lines[$k] =~ tr/[A-Z][a-z][0-9]\_?\- \*//cd; ### Remove any character that is not a letter, number, space or one of: _,?,-,*
			$lines[$k] =~ tr/ / /s; ### Replace multiple spaces with one space.
			my @line = split(/ /, $lines[$k]);
			if(length($line[0]) && length($line[1])){			
				if(keys(%o)){
					if(exists($o{$line[0]})){
						$matrix->[$k][0] = '@OUTGROUP_' . $line[0];
					}
					else {
							$matrix->[$k][0] = '@INGROUP_' . $line[0];
					}
				}
				else {
						$matrix->[$k][0] = $line[0];
				}
				my $seq = uc(join('', @line[1..$#line]));
				$seq =~ tr/\*X/\?\?/; ### Replace * and X (stop codons) with ?
				$seq =~ tr/ACDEFGHIKLMNOPQRSTUVWY\?\-//cd; ### Allow only AA letters or ? or - in alignment
				my @aa = split (//, $seq);
				if($chars && ($chars != $#aa)){					
					print(LOG "The number of characters differs within partition '$partition'! This partition has been omitted.\n");
					return();
				}
				$chars = $#aa;	
				for(my $j = $#aa; $j >= 0; $j--){
					$matrix->[$k][$j+1] = $aa[$j];					
				}
			}
		}
		undef(@lines);	
				
		############################### MOP UNINFORMATIVE AND RECODE
		my @informative = ();
		my %Murphy10 = (
			'A' => 0,
			'C' => 1,
			'D' => 2,
			'E' => 2,
			'F' => 3,
			'G' => 4,
			'H' => 5,
			'I' => 6,
			'K' => 7,
			'L' => 6,
			'M' => 6,
			'N' => 2,
			'O' => 7, ### Not in Murphy et al., but not likely to be in real data either. Treated as K.
			'P' => 8,
			'Q' => 2,
			'R' => 7,
			'S' => 9,
			'T' => 9,
			'U' => 1, ### Not in Murphy et al., but not likely to be in real data either. Treated as C.
			'V' => 6,
			'W' => 3,
			'Y' => 3
		);
		my @numeric = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V');
		for(my $j = $#{$matrix->[0]}; $j > 0; $j--){
			my %score = ();
			my $states = 0;
			for(my $k = $#{$matrix}; $k >= 0; $k--){
				if(($matrix->[$k][$j] ne '?') && ($matrix->[$k][$j] ne '-')){
					if(!exists($score{$matrix->[$k][$j]})){
						$score{$matrix->[$k][$j]} = 0;
						$states++;						
					}
					$score{$matrix->[$k][$j]} += 1;
				}
			}
			if($states > 1){
				my $minSteps = $states - 1;
				my $maxSteps = 0;
				my @steps = sort({$score{$b} <=> $score{$a}} keys(%score));
				for(my $i = $#steps; $i > 0; $i--){
					$maxSteps += $score{$steps[$i]};
				}
				if(($maxSteps - $minSteps) > 0){
					push(@informative, $j);
					if($m){
						for(my $k = $#{$matrix}; $k >= 0; $k--){
							if(($matrix->[$k][$j] ne '?') && ($matrix->[$k][$j] ne '-')){
								$matrix->[$k][$j] = $Murphy10{$matrix->[$k][$j]};
							}
						}
					}
					elsif($r){
						my %state = ();
						$states = 0;
						for(my $k = $#{$matrix}; $k >= 0; $k--){
							if(($matrix->[$k][$j] ne '?') && ($matrix->[$k][$j] ne '-')){
								if($score{$matrix->[$k][$j]} == 1){
									$matrix->[$k][$j] = '?';									
								}
								else {				
									if(!exists($state{$matrix->[$k][$j]})){
										$state{$matrix->[$k][$j]} = $numeric[$states];
										$states++;						
									}
									$matrix->[$k][$j] = $state{$matrix->[$k][$j]};
								}
							}
						}
					}
					if($maxStates < $states){
						$maxStates = $states + 1;
					}
				}
			}
		}
		if($#informative >= 0){
			$characters += $#informative + 1;
		}		
		
		############################### OUTPUT
		my $output = ();
		if($#informative >= 0){
			if($m || $r){
				$output = "&[num]\n";
			}
			else {
				$output = "&[prot nogaps]\n";
			}
			
			############################### MAX LABEL SIZE
			my $max = 0;
			for(my $k = $#{$matrix}; $k >= 0; $k--){					
				if($max < length($matrix->[$k][0])){
					$max = length($matrix->[$k][0]);
				}
			}
			$max += 5;
			
			############################### MATRIX
			for(my $k = 0; $k <= $#{$matrix}; $k++){					
				$output .= $matrix->[$k][0] . (' ' x ($max - length($matrix->[$k][0])));
				for(my $j = $#informative; $j >= 0; $j--){
					$output .= $matrix->[$k][$informative[$j]];
				}
				$output .= "\n";
			}
			if($output ne ""){$pnames .="$part: $partition\n"}
			$output .= "\n";
		}
		$part++;
		if($output eq ""){
			print(LOG "Partition $part: $partition is empty\n");
		}
		return($output);
	}
	close(LOG);
}
else { ############################### PRINT USAGE INFO
	print(STDERR "\nA PERL script for outputting a TNT matrix from an OrthologID NEXUS matrix.\n");
	print(STDERR "To conserve RAM, sequences are recoded (-r) to alpha-numeric and uninformative\n");
	print(STDERR "characters and character states are deleted.\n");
	print(STDERR "Optionally, amino acids can be recoded (-m) following the 10 letter code of\n");
	print(STDERR "Murphy et al. (2000; DOI:10.1093/protein/13.3.149).\n\n");
	print(STDERR "USAGE: nexus2tnt -n infile.nex [-o outgroup1 -o outgroup2 ...] [-m] [-r]\n\n");
	print(STDERR "WHERE: infile is a NEXUS file output by OrthologID (other NEXUS files\n");
	print(STDERR "will likely fail in strange ways).\n\n");
}
