#!/bin/bash
#echo arg $@
JOBID=$(qsub $@ )
#qsub $@
RC=$?
echo $JOBID
#echo $RC
exit 0
#exit qsub $@
