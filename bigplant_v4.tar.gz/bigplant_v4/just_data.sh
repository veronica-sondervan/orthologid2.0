#!/bin/ksh
export OID_USER_DIR=`pwd`
export OID_HOME=/home/cmz209/orthotnt/OID_nw3
OID_DATA=$OID_USER_DIR/data
Fam=$1;
cd $OID_DATA/$Fam
runtntx.pl 3 pf
 

