#!/bin/ksh 
Ppn=${1:-3}
Mem=${4:-12}
Wall=${5:-24}
JOB_SCRIPT=$OID_USER_DIR/run_tntx.sh
GB="GB"
Mem=$Mem$GB
echo  ppn=$Ppn mem=$Mem wall=$Wall
#qsub -l nodes=1:ppn=$Ppn,walltime=$Wall:00:00 -l mem=$Mem $JOB_SCRIPT -v arg1="$1",arg2="$2",arg3="$3"
nbla=$(ls blast | grep -c 'Part.*faa')
echo hi
#print "$nbla" -> no of blasts $nbla
val=$nbla
echo $val
