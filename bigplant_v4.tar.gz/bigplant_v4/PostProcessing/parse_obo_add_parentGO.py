#!/usr/bin/env python
#
# By Gil Eshel, Sep 12, 2017
#
# A script to include parent GO terms (is_a and part_of) to a provided gene2go annotation tab-delimited gene_id<\t>GO_id_list_comma_separated) - for Fisher Exact test
# Takes as input the gene2go.txt (tab-delimited gene_id<\t>GO_id_list_comma_separated), downloads the latest go-basic.obo file (http://geneontology.org/page/download-ontology) with the GO parent / alternative information, parse it and add parent GO terms to the gene2go annotation file (keep a unique set of GO_ids for each gene_id...) - this output will be use fot the GO enrichment analysis.
# I adopted the obo file parsing code from Damian Kao (http://blog.nextgenetics.net/?e=6) - I modified it to include both is_a and part_of as parent GO_ids. Thank you Damian Kao for a great post!
#
# synopsis : parse_obo_add_parentGO.py <gene2go.txt> <gene2go_with_parents.txt>

import sys, subprocess, itertools, os # sys is for retrieving the script arguments, subprocess used for executing bash commands from within the python script, itertools is for grouping the line of each GO term in the go-basic.obo file together (separated by a blank line), os is for checking if the go-basic.obo file exists already in the working DIR

### get most recent go-basic.obo file
if not os.path.exists('go-basic.obo'):
	try:
		subprocess.call(" ".join(["wget", "http://purl.obolibrary.org/obo/go/go-basic.obo"]), shell=True)
	except:
		print "go-basic.obo could not be download"

	print 'downloaded obo file - yeee'

### parse the go-basic.obo to retrieve parent GO terms:
# few parsing functions:
def getTerm(stream):
	block = []
	for line in stream:
		if line.strip() == "[Term]" or line.strip() == "[Typedef]":
			break
		else:
			if line.strip() != "":
				block.append(line.strip())
	return block

print 'loaded getTerm function'

def parseTagValue(term):
	data = {}
	for line in term:
		if line.startswith('relationship: part_of'):
			tag = line.split(' ')[1] # tag = 'part_of'
			value = line.split(' ')[2] # collect the GO_id
		elif line.startswith('is_a'):
			tag = line.split(': ',1)[0] # tag = 'is_a'
			value = line.split(': ',1)[1].split()[0] # collect the GO_id
		else:
			tag = line.split(': ',1)[0] # other tags like 'id:', 'name:', 'namespace:' etc. are collected
			value = line.split(': ',1)[1]
		if not data.has_key(tag):
			data[tag] = []
		data[tag].append(value)
	return data

print 'loaded parseTagValue function'

oboFile = open('go-basic.obo','r')
print 'opened oboFile - yeee!'

terms = {} # declare a blank dictionary - keys are the GOids and the values will be their parent and Child GO_ids
getTerm(oboFile) #skip the file header lines
go_names = [] # # to store the 'GO_id | GO_term' info
while 1: #infinite loop to go through the obo file. Breaks when the term returned is empty, indicating end of file
	term = parseTagValue(getTerm(oboFile)) #get the term using the two parsing functions
	if len(term) != 0:
		termID = term['id'][0]
		termParents = []
		if term.has_key('is_a') or term.has_key('part_of'): #only add to the structure if the term has a 'is_a' or a 'part_of' tags. the is_a value contain GO_id and term definition =- we only want the GO_id
			if term.has_key('is_a'):
				termParents.append([term[x] for x in ['is_a']])
			if term.has_key('part_of'):
				termParents.append([term[x] for x in ['part_of']])
			termParents = [j for i in termParents for j in i] # flattens the list of lists...
			#print termParents
			if not terms.has_key(termID):
				terms[termID] = {'p':[],'c':[]} # each GO_id will have two arrays of parents and children
			terms[termID]['p'] = termParents # append parents of the current term
			for termParent in termParents: #for every parent term, add this current term as children
				for i in termParent:
					if not terms.has_key(i):
						terms[i] = {'p':[],'c':[]}
					terms[i]['c'].append(termID)
		#elif term.has_key('name'):
		go_names.append(''.join(term['id']) + ' | ' + ''.join(term['name'])) # store the 'GO_id | GO_term' info, e.g. 'GO:0000008 | obsolete thioredoxin' 
	else:
		break
oboFile.close()
print 'parsed obo file - yeee'

### Parse the user provided gene2go.txt file to add the parent GO_ids:
gene_to_go = [] # a list to store the gene<\t>GO_all<\n> strings
with open(sys.argv[1], 'r') as goFile:
	for line in goFile:
		GO_parents = []
		li=line.strip()
		gene = li.split('\t')[0]
		GO = li.split('\t')[1].split(',')
		for go in GO:
			if go in terms.keys():
				GO_parents.append(terms[go]['p'])
		GO_parents = [item for sublist in GO_parents for item in sublist] # just to reduce complexity - convert from list of lists of lists, to list of lists
		GO_parents = [item for sublist in GO_parents for item in sublist] # just to reduce complexity - convert from list of lists to a list
		GO_all = ','.join(list(set(','.join(GO).split(',') + GO_parents))) # merge the GO list (original) with the GO_parents list to a unique list of GO_ids - join them to a comma-separated string
		gene_to_go.append(gene + '\t' + GO_all)
print 'parsed gene2go file - yeee!'	

### open an output file to print into the new annotation file with the parent GO_ids included
with open(sys.argv[2], "w") as output:
    output.write('\n'.join(gene_to_go))

### open an output file to print into the GO_id to GO description file
with open('GoDesc.txt', "w") as output:
    output.write('\n'.join(go_names))
	




 