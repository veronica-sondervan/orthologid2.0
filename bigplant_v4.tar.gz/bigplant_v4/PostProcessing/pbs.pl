#!/usr/bin/perl

############################### This program is free software; you can redistribute it and/or modify
############################### it under the terms of the GNU General Public License as published by
############################### the Free Software Foundation; either version 2 of the License, or
############################### (at your option) any later version.
############################### 
############################### This program is distributed in the hope that it will be useful,
############################### but WITHOUT ANY WARRANTY; without even the implied warranty of
############################### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
############################### GNU General Public License for more details.
############################### 
############################### You should have received a copy of the GNU General Public License
############################### along with this program; if not, write to the Free Software
############################### Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
###############################
###############################
###############################
############################### Copyright 2013 Damon P. Little
my $l = ();
my $m = ();
my %n = ();
my $t = ();
for(my $k = $#ARGV; $k >= 0; $k--){
	if($ARGV[$k] eq '-l'){
		if(-e $ARGV[$k+1]){
			print(STDERR "Logfile $l will be overwritten!\n");
			}
		if(length($ARGV[$k+1])){
			$l = $ARGV[$k+1];
			}
		next;	
		}
	if($ARGV[$k] eq '-m'){
		if(-e $ARGV[$k+1]){
			$m = $ARGV[$k+1];
			}
		next;	
		}
	if($ARGV[$k] eq '-n'){
		if(-e $ARGV[$k+1]){
			$n = $ARGV[$k+1];
			}
		next;	
		}
	if($ARGV[$k] eq '-t'){
		if(-e $ARGV[$k+1]){
			$t = $ARGV[$k+1];
			}
		next;	
		}
	}

	

############################### MODULE
use Text::Balanced qw(extract_bracketed);



if(length($l) && length($m) && length($n) && length($t)){

	############################### PROC FILE
	my $p = 0;
	open(INFILE, $m) || die("Could not open $m!");
	while(my $line = <INFILE>){
		chomp($line);
		if(($line =~ m/^&\[/) && ($line =~ m/\]$/)){
			$p++
			}
		}
	close(INFILE);
	
	my %clades = ();
	my $terminals = 0;
	open(INFILE, $n) || die("Could not open $n!");
	while(my $line = <INFILE>){
		chomp($line);
		if(length($line) && ($line !~ m/^tread/) && ($line ne 'proc-;')){
			$line =~ tr/0123456789 \(\)//cd;
			my $remainder = substr($line, index($line, '('));
			$terminals = ($line =~ tr/ / /);
			while(($remainder =~ m/\(/) && ($remainder =~ m/\)/)){
				my @bits = extract_bracketed($remainder, '()');
				$bits[0] = substr($bits[0], 1, (length($bits[0])-2));
				if(($bits[0] =~ m/\(/) && ($bits[0] =~ m/\)/)){
					$remainder = substr($bits[0], index($bits[0], '(')) . $bits[1];
					} else {
						$remainder = $bits[1];
						}
				$bits[0] =~ tr/0123456789 /0123456789 /cds;
				$bits[0] =~ s/ $//g;
				$clades{$bits[0]} = scalar(split(/ /, $bits[0]));				
				}
			last;
			}
		}
	close(INFILE);
	
	my $tnt = "log $l;\n";
	$tnt .= "mxram 32000;\n";
	$tnt .= "p $m;\n";
	$tnt .= "p $t;\n";
	for(my $k = $p; $k > 0; $k--){
		$tnt .= "quote UNCONSTRAINED PARTITON $k;\n";
		$tnt .= "cc].;\n";
		$tnt .= "cc[\@$k.;\n";
		$tnt .= "len;\n";		
		}
	$tnt .= "quote BEGIN PBS;\n";
	$tnt .= "hold 1000;\n";
	$tnt .= "rat:iter50up4do4;\n";
	$tnt .= "mult:rep1ho1rat;\n";
	my @clades = keys(%clades);
	for(my $k = $#clades; $k >= 0; $k--){
		if($clades{$clades[$k]} < ($terminals-1)){
			$tnt .= "k0;\n";
			$tnt .= "force-[$clades[$k]];\n";
			$tnt .= "const=;\n";
			$tnt .= "cc[.;\n";
			$tnt .= "mult;\n";
			$tnt .= "bb;\n";
			for(my $j = $p; $j > 0; $j--){
				$tnt .= "quote CONSTRAINED PARTITON $j NODE $k;\n";
				$tnt .= "cc].;\n";
				$tnt .= "cc[\@$j.;\n";
				$tnt .= "len;\n";		
				}
			}
		}
   $tnt .= "quote END PBS;\n";
   $tnt .= "log/;\n";
   $tnt .= "zz;\n";
   $tnt .= "proc/;\n";
   open(OUTFILE, ">temporary-tnt.proc") || die("Could not open temporary-tnt.proc!");
   print(OUTFILE $tnt);
   close(OUTFILE);
   exit(0);
   ############################### TNT
	qx/tnt bground p temporary-tnt.proc/;
	unlink(temporary-tnt.proc);
	
	############################### READ LOG
	open(INFILE, $l) || die("Could not open $l!");
	my $buffer = "clade,partition,pbs\n";
	my $constrained = -1;
	my $k = 0;
	my @lengths = ();
	my $node = ();
	my @partitions = ();
	my $tree = 0;
	my $unconstrained = -1;
	while(my $line = <INFILE>){
		chomp($line);
		$line =~ tr/ / /s;
		$line =~ s/^ //g;
		if(length($line)){
			my @bits = split(/ /, $line);
			if($tree && ($k == 2)){
				push(@lengths, @bits[1..$#bits]);
				next;				
				}
			if($tree && ($k == 3)){	
				$tree = 0;
				my $mean = ();
				for(my $j = $#lengths; $j >= 0; $j--){
					$mean += $lengths[$j];					
					}
				$mean = $mean / ($#lengths+1);	
				if(($unconstrained != -1) && ($mean >= 0)){
					$partitions[$unconstrained] = $mean;	
					} elsif(($constrained != -1) && ($mean >= 0)){
						$buffer .= $clades[$node] . ',' . $constrained . ',' . sprintf('%.4f', ($mean - $partitions[$constrained])) . "\n";
						if(length($buffer) > 10000){
							print($buffer);
							$buffer = ();
							}
						} else {
							print(STDERR "Error reading TNT log file!\n");
							last;
							}
				}
			if(($bits[0] eq 'UNCONSTRAINED') && ($bits[1] eq 'PARTITON')){
				$unconstrained = $bits[2];
				next;
				}
			if(($bits[0] eq 'CONSTRAINED') && ($bits[1] eq 'PARTITON')){
				$constrained = $bits[2];
				$node = $bits[4];
				$unconstrained = -1;
				next;
				}
			if(($bits[0] eq 'Tree') && ($bits[1] eq 'lengths')){
				$k = 0;
				$tree = 1;
				@lengths = ();
				next;
				}
			} else {
				$k++;
				}
		}
	close(INFILE);
	print($buffer);
	
	
	
	} else { ############################### PRINT USAGE INFO
		print("\nA PERL script for computing Partition Bremer Support with TNT.\n");
		print("USAGE: pbs.pl -l logfile.log -m matrix.tnt -n consensus.nel -t trees.tre\n\n");
		print("WHERE: Matrix is a TNT formatted matrix with one partion per data block.\n");
		print("The consensus tree and the most parsimonious trees must be in numeric format.\n\n");
		}

