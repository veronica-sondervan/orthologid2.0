#!/bin/sh
#
# PBS job script for orthologid
#

#PBS -S /bin/bash
#PBS -j oe
##PBS -l mem=12GB
##PBS -o /scratch/cmz209/orthotnt/oidTest8/log/job
#PBS -q cgsb-s
#PBS -N oidTest9
#PBS -V 

PATH=/home/cmz209/orthotnt/OID_nw3/bin:/home/cmz209/orthotnt/OID_nw3/bin:/home/cmz209/orthotnt/OID_nw3/bin:/home/cmz209/orthotnt/OID_nw3/bin:/share/apps/mafft/7.154b/intel/bin:/share/apps/mcl/14-137/intel/bin:/share/apps/trinityrnaseq/20140717/intel/util:/share/apps/trinityrnaseq/20140717/intel:/share/apps/gmap/20140704/intel/bin:/share/apps/quake/0.3.5/intel/bin:/share/apps/jellyfish/2.1.3/intel/bin:/share/apps/r/3.0.3/intel/bin:/share/apps/hydra/3.1/intel/bin:/share/apps/mvapich2/2.0rc1/intel/bin:/share/apps/icu/52.1/gnu/sbin:/share/apps/icu/52.1/gnu/bin:/share/apps/blast+/2.2.29/bin:/share/apps/perl/5.18.2/intel/bin:/share/apps/mysql/5.6.16/bin:/share/apps/libgd/2.1.0/gnu/bin:/share/apps/libtiff/4.0.3/gnu/bin:/share/apps/libxslt/1.1.28/intel/bin:/share/apps/libxml2/2.9.1/intel/bin:/share/apps/berkeleydb/12.1.6.0.30/intel/bin:/share/apps/bowtie2/2.2.3/intel/scripts:/share/apps/bowtie2/2.2.3/intel/bin:/share/apps/bowtie/1.1.1/intel/scripts:/share/apps/bowtie/1.1.1/intel/bin:/share/apps/samtools/1.2/intel/bin:/share/apps/samtools/1.2/intel/misc:/share/apps/ncurses/5.9/gnu/bin:/share/apps/soapdenovo2/r240/intel/bin:/share/apps/python/2.7.6/intel/bin:/share/apps/bzip2/1.0.6/intel/bin:/share/apps/hdf5/1.8.12/intel/bin:/share/apps/enchant/1.6.0/intel/bin:/share/apps/llvm/3.2/gnu/bin:/share/apps/qt/4.8.5/intel/bin:/share/apps/expat/2.1.0/intel/bin:/share/apps/dbus/1.8.0/gnu/bin:/share/apps/cairo/1.12.16/gnu/bin:/share/apps/sqlite/3.8.4.1/intel/bin:/share/apps/intel/14.0.2/composer_xe_2013_sp1.2.144/bin/intel64:/usr/lib64/qt-3.3/bin:/opt/moab/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/ganglia/bin:/opt/ganglia/sbin:/opt/ibutils/bin:/usr/java/latest/bin:/opt/rocks/bin:/opt/rocks/sbin:/opt/dell/srvadmin/bin:/opt/torque/bin:/opt/torque/sbin:/home/cmz209/bin:/opt/torque/bin:/opt/torque/sbin:/home/cmz209/bin:/opt/torque/bin:/opt/torque/sbin:/home/cmz209/bin:/opt/torque/bin:/opt/torque/sbin:/home/cmz209/bin:/opt/torque/bin:/opt/torque/sbin:/home/cmz209/bin


OID_DATA=$OID_USER_DIR/data
Fam="$arg1"
cd $OID_DATA/$Fam
tnt p "$arg2"
 

