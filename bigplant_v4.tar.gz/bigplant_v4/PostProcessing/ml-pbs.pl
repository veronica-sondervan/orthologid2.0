#!/usr/bin/perl

############################### This program is free software; you can redistribute it and/or modify
############################### it under the terms of the GNU General Public License as published by
############################### the Free Software Foundation; either version 2 of the License, or
############################### (at your option) any later version.
############################### 
############################### This program is distributed in the hope that it will be useful,
############################### but WITHOUT ANY WARRANTY; without even the implied warranty of
############################### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
############################### GNU General Public License for more details.
############################### 
############################### You should have received a copy of the GNU General Public License
############################### along with this program; if not, write to the Free Software
############################### Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
###############################
###############################
###############################
############################### Copyright 2017 Damon P. Little
my $m = '';
my @p = ();
for(my $k = $#ARGV; $k >= 0; $k--){
	if($ARGV[$k] eq '-m'){
		if(-e $ARGV[$k+1]){
			$m = $ARGV[$k+1];
		}
		next;	
	}
	if($ARGV[$k] eq '-p'){
		my @bits = split(/,/, $ARGV[$k+1]);
		for(my $j = $#bits; $j >= 0; $j--){
			if(-e $bits[$j]){
				push(@p, $bits[$j]);
			}
		}
	}
}

############################### MODULES
use strict;
use Text::Balanced qw(extract_bracketed);

if(length($m) && length(@p)){

	############################### MAKE MATRIX OF GROUP MEMBERSHIP VARIABLES
	my %clades = ();
	my $ntax = 0;
	my %terminals = ();
	open(INFILE, $m) or die("Could not open $m!");
	while(my $line = <INFILE>){
		chomp($line);
		if(length($line)){
			$line =~ s/:0\.[0-9]{1,}[,;]/,/g;
			$line =~ s/:0\.[0-9]{1,}\)/\)/g;
			$line =~ s/,$//;
			my $list = $line;
			$list =~ s/\(|\)//g;
			$list =~ tr/,/,/s;
			$ntax = scalar(split(/,/, $list));
			my $remainder = substr($line, index($line, '('));
			while(($remainder =~ m/\(/) && ($remainder =~ m/\)/)){		
				$remainder =~ s/^[A-z0-9]{0,},//;
				$remainder =~ s/,[A-z0-9]{0,}$//;
				my @bits = extract_bracketed($remainder, '()');
				$bits[0] = substr($bits[0], 1, (length($bits[0])-2));
				if(($bits[0] =~ m/\(/) && ($bits[0] =~ m/\)/)){
					$remainder = substr($bits[0], index($bits[0], '(')) . $bits[1];
				} else {
					$remainder = $bits[1];
				}
				$bits[0] =~ s/\(|\)//g;
				$bits[0] =~ tr/,/,/s;
				if(length($bits[0])){
					my @taxa = split(/,/, $bits[0]);
					for(my $k = $#taxa; $k >= 0; $k--){
						$terminals{$taxa[$k]} = '';
					}
					$bits[0] =~ tr/,/ /;
					if($#taxa+1 < $ntax){
						$clades{$bits[0]} = $#taxa+1;
					}
				}
			}
			last;
		}
	}
	close(INFILE);	
	my $groupMembershipMatrix = ();
	my @clade = keys(%clades);
	my @terminal = keys(%terminals);
	for(my $k = $#terminal; $k >= 0; $k--){
		for(my $j = $#clade; $j >= 0; $j--){
			if(($clade[$j] =~ m/^$terminal[$k] /) || ($clade[$j] =~ m/ $terminal[$k] /) || ($clade[$j] =~ m/ $terminal[$k]$/)){
				$groupMembershipMatrix->[$k][$j] = 1;
			} else {
				$groupMembershipMatrix->[$k][$j] = 0;
			}
		}
	}
	my $autapomorphyMatrix = ();
	for(my $k = $#terminal; $k >= 0; $k--){
		for(my $j = $#terminal; $j >= 0; $j--){
			if($k == $j){
				$autapomorphyMatrix->[$k][$j] = 1;
			} else {
				$autapomorphyMatrix->[$k][$j] = 0;
			}
		}
	}

	############################### GET ML OF EACH PARTITION ON THE COMBINED TREE
	my $nchar = 0;
	my @partitions = ();
	my %unconstrainedML = ();
	for(my $j = $#p; $j >= 0; $j--){
		open(INFILE, $p[$j]) or die("Could not open $p[$j]!");
		my $t = '';
		while(my $line = <INFILE>){
			chomp($line);
			if(length($line)){
				if($line =~ m/^>/){
					$t = $line;
					$t =~ s/^>//;
					$terminals{$t} = '';
				} else {
					uc($line);
					$line =~ tr/ABCDEFGHIKLMNOPQRSTUVWXYZ\-//cd;
					$terminals{$t} .= $line;
				}
			}
		}
		close(INFILE);
		$partitions[$j] = $p[$j];
		$partitions[$j] =~ s/\.fasta//;
		my $partition = 'temporary-' . $partitions[$j];
		open(OUTFILE, ">$partition.phy") or die("Could not open $partition.phy!");
		my $l = length($terminals{$t});
		$nchar += $l;
		my $buffer = ($#terminal+1) . ' ' . $l . "\n";
		for(my $k = $#terminal; $k >= 0; $k--){
			$buffer .= $terminal[$k] . "\t";
			if(length($terminals{$terminal[$k]}) == $l){
				$buffer .= $terminals{$terminal[$k]};	
			} elsif(length($terminals{$terminal[$k]}) == 0){
				$buffer .= '?' x $l;
			} else {
				die("Error reading $p[$j], sequence for $t is not correct!\n");	
			}
			$buffer .= "\n";
			if(length($buffer) > 10000){
				print(OUTFILE $buffer);
				$buffer = '';
			}
		}
		print(OUTFILE $buffer);
		close(OUTFILE);
		unlink('RAxML_log.' . $partition);
		unlink('RAxML_result.' . $partition);
		unlink('RAxML_binaryModelParameters.' . $partition);
		unlink('RAxML_info.' . $partition);
		unlink('RAxML_proteinGTRmodel.' . $partition . '_Partition_No Name Provided');
		my $raxml = 'raxml -T `getconf _NPROCESSORS_ONLN` -f e -s ' . $partition . '.phy -m PROTGAMMAGTRX -n ' . $partition . ' -t ' . $m;
		qx/$raxml/;
		open(INFILE, 'RAxML_log.' . $partition) or die("Could not open RAxML_log.$partition!");
		while(my $line = <INFILE>){
			chomp($line);
			if(length($line)){
				my @bits = split(/ /, $line);
				$bits[1] =~ tr/\-\.[0-9]//cd;
				if(length($bits[1])){
					$unconstrainedML{$partitions[$j]} = $bits[1];
				} else {
					die("Cannot comput ML for $partitions[$j]!\n");
				}
			}
		}
		close(INFILE);
		unlink('RAxML_log.' . $partition);
		unlink('RAxML_result.' . $partition);
		unlink('RAxML_binaryModelParameters.' . $partition);
		unlink('RAxML_info.' . $partition);
		unlink('RAxML_proteinGTRmodel.' . $partition . '_Partition_No Name Provided');
	}
	
	############################### CREATE COMBINED MATRIX
	my $c = $#{$groupMembershipMatrix->[0]}+1+$#{$autapomorphyMatrix->[0]}+1;
	my $combined = 'temporary-combined';
	my $part = 'BIN, p1=1-' . $c . "\n";
	open(OUTFILE, ">$combined.phy") or die("Could not open $combined.phy!");
	my $buffer = $ntax . ' ' . ($nchar+$c) . "\n";
	for(my $k = $#{$groupMembershipMatrix}; $k >= 0; $k--){
		$buffer .= $terminal[$k] . "\t"; 
		for(my $j = $#{$groupMembershipMatrix->[$k]}; $j >= 0; $j--){
			$buffer .= $groupMembershipMatrix->[$k][$j];
		}
		for(my $j = $#{$autapomorphyMatrix->[$k]}; $j >= 0; $j--){
			$buffer .= $autapomorphyMatrix->[$k][$j];
		}
		$buffer .= "\n";
	}
	$buffer .= "\n";
	for(my $j = $#p; $j >= 0; $j--){
		open(INFILE, $p[$j]) or die("Could not open $p[$j]!");
		my $t = '';
		while(my $line = <INFILE>){
			chomp($line);
			if(length($line)){
				if($line =~ m/^>/){
					$t = $line;
					$t =~ s/^>//;
					$terminals{$t} = '';
				} else {
					uc($line);
					$line =~ tr/ABCDEFGHIKLMNOPQRSTUVWXYZ\-//cd;
					$terminals{$t} .= $line;
				}
			}
		}
		close(INFILE);
		my $l = length($terminals{$t});
		$part .= 'GTR, p' . ($#p-$j+2) . '=' . ($c+1) . '-';
		$c += $l;
		$part .= $c . "\n";
		for(my $k = $#terminal; $k >= 0; $k--){
			if(length($terminals{$terminal[$k]}) == $l){
				$buffer .= $terminals{$terminal[$k]};	
			} elsif(length($terminals{$terminal[$k]}) == 0){
				$buffer .= '?' x $l;
			} else {
				die("Error reading $p[$j], sequence for $t is not correct!\n");	
			}
			$buffer .= "\n";
			if(length($buffer) > 10000){
				print(OUTFILE $buffer);
				$buffer = '';
			}
		}
		$buffer .= "\n";
	}
	print(OUTFILE $buffer);
	close(OUTFILE);
	open(OUTFILE, ">$combined.part") or die("Could not open $combined.part!");
	print(OUTFILE $part);
	close(OUTFILE);
	
	############################### SEARCH COMBINED MATRIX WITH NEGATIVE WEIGHTS FOR EACH CLADE, GET ML OF EACH PARTITION ON THE RESULTING TREE
	my %constrainedML = ();
	my $autoWeight = int(100000/($#{$autapomorphyMatrix->[0]}+1))+1;
	for(my $j = $#{$groupMembershipMatrix->[0]}; $j >= 0; $j--){
		my $weights = "0\n" x $j;
		$weights .= "-100000\n";
		$weights .= "0\n" x ($#{$groupMembershipMatrix->[0]}-$j);
		$weights .= "$autoWeight\n" x ($#{$autapomorphyMatrix->[0]}+1);
		$weights .= "1\n" x ($c-$#{$groupMembershipMatrix->[0]}-1-$#{$autapomorphyMatrix->[0]}-1);
		open(OUTFILE, ">$combined.weight") or die("Could not open $combined.weight!");
		print(OUTFILE $weights);
		close(OUTFILE);
		unlink('RAxML_bestTree.' . $combined);
		unlink('RAxML_log.' . $combined);
		unlink('RAxML_result.' . $combined);
		unlink('RAxML_info.' . $combined);          
		unlink('RAxML_parsimonyTree.' . $combined);
		my $raxml = 'raxml -T `getconf _NPROCESSORS_ONLN` -f d -s ' . $combined . '.phy -m PROTGAMMAGTRX -n ' . $combined . ' -q ' . $combined . '.part -a ' . $combined . '.weight -p $RANDOM';
		qx/$raxml/;
		unlink('RAxML_log.' . $combined);
		unlink('RAxML_result.' . $combined);
		unlink('RAxML_info.' . $combined);          
		unlink('RAxML_parsimonyTree.' . $combined);
		for(my $j = $#partitions; $j >= 0; $j--){
			my $partition = 'temporary-' . $partitions[$j];
			unlink('RAxML_log.' . $partition);
			unlink('RAxML_result.' . $partition);
			unlink('RAxML_binaryModelParameters.' . $partition);
			unlink('RAxML_info.' . $partition);
			unlink('RAxML_proteinGTRmodel.' . $partition . '_Partition_No Name Provided');
			$raxml = 'raxml -T `getconf _NPROCESSORS_ONLN` -f e -s ' . $partition . '.phy -m PROTGAMMAGTRX -n ' . $partition . ' -t RAxML_bestTree.' . $combined;
			qx/$raxml/;
			open(INFILE, 'RAxML_log.' . $partition) or die("Could not open RAxML_log.$partition!");
			while(my $line = <INFILE>){
				chomp($line);
				if(length($line)){
					my @bits = split(/ /, $line);
					$bits[1] =~ tr/\-\.[0-9]//cd;
					if(length($bits[1])){
						$constrainedML{$partitions[$j]} = $bits[1];
					} else {
						die("Cannot comput ML for $partitions[$j]!\n");
					}
				}
			}
			close(INFILE);
			unlink('RAxML_log.' . $partition);
			unlink('RAxML_result.' . $partition);
			unlink('RAxML_binaryModelParameters.' . $partition);
			unlink('RAxML_info.' . $partition);
			unlink('RAxML_proteinGTRmodel.' . $partition . '_Partition_No Name Provided');
		}
		unlink('RAxML_bestTree.' . $combined);
		unlink($combined . '.weight');
	}
	unlink($combined . '.phy');
	unlink($combined . '.part');
	for(my $j = $#partitions; $j >= 0; $j--){
		unlink('temporary-' . $partitions[$j] . '.phy');
		unlink('RAxML_proteinGTRmodel.temporary-combined_Partition_p' . ($#p-$j+2));
	}

	############################### CALCULATE PBS
	$buffer = "clade,partition,ml-pbs\n";
	for(my $k = $#clade; $k >= 0; $k--){
		for(my $j = $#partitions; $j >= 0; $j--){
			$buffer .= $clade[$k] . ',' . $partitions[$j] . ',' . sprintf('%.6f', ($constrainedML{$partitions[$j]}-$unconstrainedML{$partitions[$j]})) . "\n";
			if(length($buffer) > 10000){
				print($buffer);
				$buffer = '';
			}
		}
	}
	print($buffer);
	
} else { ############################### PRINT USAGE INFO
	print(STDERR "\nA PERL script for computing Partition Bremer Support with RAxML.\n");
	print(STDERR "USAGE: ml-pbs.pl -p partition1.fasta,partitionB.fasta,partitionC.fasta,... -m best.tree\n\n");
}

exit(0);
