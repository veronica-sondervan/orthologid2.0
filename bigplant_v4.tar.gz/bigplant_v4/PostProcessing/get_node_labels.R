# Gil Eshel, June 9, 2017
# Script to add node labels ("N#") to the newick tree and to retreive node number to node/tip label table to be used when parsing the pbs.csv file
# # synopsis : Rscript get_node_labels.R <mpt_fixed.tre file> <mpt_nel_fixed.tre file> 
# Output 1: node_number_to_label.txt - a table of tip/node number to tip/node label assostiation (for parsing the pbs.csv results)
# Output 2: mpt_nel_fixed_labeled.tre - the tree with the tip and node labels (short species names and the "N#" notation on the tree for PhyloBrowse) - use the labels_to_full_names.py script to replace species labels with full names
# Output 3: patristic_distances_tips.csv - the patristic distances matrix between any pairs of species (between only the tips)
# Output 4: patristic_distances_tips.csv - the patristic distances matrix between any node or tip in the tree (this can be used for normalizing the PBS values of more higher level nodes)

library(ape) # to read the phylogenetic tree
library(phytools) # to get node descendents
#library(geiger)?
#library(phylobase)?

### Functions ###

# function to correct the node descendent numbers according to the mpt_fixed.tre tip.label vector - It uses the indices and the values of the tip.label vector to do that 
fix_tip_numbers <- function(descendent_vector,tip.label_vector){
  for (i in 1:length(descendent_vector)) {
    descendent_vector[i]=tip.label_vector[descendent_vector[i]]}
  return(descendent_vector)
}


args = commandArgs(TRUE)

### Read the trees:  
mpt_numbers_tree = read.tree(args[1]) # read the mpt_fixed.tre which contains only node numbers as were used for PBS calculations
mpt_nel_tree = read.tree(args[2]) # read the mpt_nel_fixed.tre which contains the species labels (short names) and brach lengths

### Get species label to number association table - use the mpt_numbers_tree to generate the species label to number association table (including the internal node labels "N#" and numbers e.g ("2 6") ) 
number = c()
label = c()
j = 1 # to set the first N# to N1...
for (i in 1:max(mpt_numbers_tree$edge)) { # loop over all tips/terminals/taxa (1, 2, 3, ... last_internal_node_number)
  if (i < length(mpt_numbers_tree$tip.label)+1) { # For the tips - save the tip label of both trees (numbers and labels)
    number = c(number, mpt_numbers_tree$tip.label[i])
    label = c(label, mpt_nel_tree$tip.label[i]) } 
  else if (i > length(mpt_numbers_tree$tip.label)) { # For the internal nodes - get the descendants numbers (e.g. "4 5 6 7 8") and label the node ("N#")
    internal_node_descend = getDescendants(mpt_numbers_tree,node=i) # get the descendants numbers - using the getDescendants function in the R package phytools
    internal_node_descend = internal_node_descend[internal_node_descend<length(mpt_numbers_tree$tip.label)+1] # get only the tip id numbers (only the terminals/taxa) of that internal node (removes the internal node numbers that connect to that node)
    internal_node_descend = fix_tip_numbers(internal_node_descend,as.numeric(mpt_numbers_tree$tip.label)) # use the above function to correct the mpt_numbers_tree$tip.label numbers and not the position (1:length(mpt_numbers_tree$tip.label))
    internal_node_descend = paste(internal_node_descend,collapse=" ") 
    number = c(number, toString(internal_node_descend)) # store the descendants numbers into one string (e.g. "4 5 6 7 8")
    label = c(label,paste("N", toString(j), sep = "")) # label the node "N#"
    mpt_nel_tree$node.label[j] = paste("N", toString(j), sep = "") # label the corresponding mpt_nel_tree$node.label as "N#"
    j=j+1
  }
}

node_number_to_label = data.frame(number,label)
write.table(node_number_to_label, sep="\t", file="node_number_to_label.txt", quote = FALSE, row.names = FALSE, col.names = TRUE) # save the node_number_to_label table

### Save the nel tree with node labels ###
write.tree(mpt_nel_tree, file = "mpt_nel_fixed_labeled.tre")
  
### Patristic distance matrix ###
patristic_distances_tips = cophenetic(mpt_nel_tree) # yields a matrix of patristic distances between all taxa  - from the cophenetic.phylo function in the R package ape
patristic_distances_all = dist.nodes(mpt_nel_tree) # yields a matrix of all patristic distances between all nodes (internal and external) - If we want to calculate the patristic distances between two internal nodes or an internal node and a tip - from the cophenetic.phylo function in the R package ape
matrix_name = c(mpt_nel_tree$tip.label, mpt_nel_tree$node.label)
colnames(patristic_distances_all) = matrix_name
rownames(patristic_distances_all) = matrix_name
write.csv(patristic_distances_tips, file="patristic_distances_tips.csv", quote = FALSE) # save the patristic_distances_tips
write.csv(patristic_distances_all, file="patristic_distances_all.csv", quote = FALSE) # save the patristic_distances_all
