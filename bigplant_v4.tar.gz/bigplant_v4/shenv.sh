#!/bin/ksh
env >env.log
echo $0 >>env.log
