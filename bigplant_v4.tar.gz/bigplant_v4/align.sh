print "Submitting alignment and tree search jobs ..."
lastfam=$(/bin/ls $OID_USER_DIR/data | grep '^[1-9]' | sort -n | tail -1)
fam=1
while ((fam<=lastfam)); do
	if qsub -l walltime=12:00:00 $JOB_SCRIPT -v arg1="-at",arg2="^$fam$" 2>/dev/null; then
		print "Family $fam"
		((fam++))
	else
		# Retry after 5 mins
		sleep 300
	fi
done
# Alernatively, use array job
#qsub -l walltime=48:00:00 -t 1:$lastfam $JOB_SCRIPT -v arg1="-at"
print "All alignment/tree search jobs submitted.  Waiting for last job to finish."

while sleep 200; do
	for i in $OID_USER_DIR/data/[1-9]*; do
		if [[ ! -f $i/oid.tre ]] || [[ ! -s $i/oid.tre ]]; then
			continue 2
		fi
	done
	break
done
