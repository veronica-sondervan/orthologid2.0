###qsub  -V -l mem=4GB -l nodes=1:ppn=2 -l walltime=04:00:00 -I -Mcmz209@nyu.edu
#PBS -I
#PBS -l mem=4GB
#PBS -l nodes=1:ppn=2,walltime=04:00:00
#PBS -Mcmz2099@nyu.edu
#PBS -I -V
##PBS -j oe
##PBS -o orthotnt/oidTest8
cd orthotnt/oidTest
#/testen.pl
#env >qsenv.log
