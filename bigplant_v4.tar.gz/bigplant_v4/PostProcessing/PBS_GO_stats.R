# Gil Eshel, June 9, 2017
# Script to run GO overrepresentation analysis for the high pbs partitions for each node on the tree
#
  # # synopsis : Rscript PBS_GO_stats.R </path/to/parse_partitionMembers.txt file> </path/to/pbs.csv file> </path/to/GO_mapping_table> <node_number_to_label.txt> <pbs absolute cutoff>
#
# Outputs:
# partition_info.txt (all the information per partition), partition_annotation_with_pbs.txt and partition_annotation_with_pbs_filtered.txt - tables with the clade (number and label), partition, pbs, model species identifer and GO annotation information (for all partitions or partitions with abs(PBS) >= PBS_cutoff) 
# 
# Commant1 - The user needs to input the goframeData table with three columns: GO_id, Evidence and Gene_id (tab-delimited). For model organisms, the user can download a GAF file for a model organism from the Gene Ontology Consortium (http://www.geneontology.org/page/download-annotations), and take these tree columns to build the goframeData table (see http://geneontology.org/page/go-annotation-file-gaf-format-21). The user have to make sure that the gene_ids in the goframeData file correspont exactly to the input sequence identifers (e.g.if a sequence header is Arath_At4g25480.1, the gene_id in goframeData needs to be At4g25480.1, not At4g25480 nor AT4G25480.1)
# Commant2 - This code needs to hendle more than one specified model species (e.g. the user can specify Arabidopsis and maize) for GO annotation - We can suggest that the goframeData file will include the GO annotations for all the model organisms, and so we can loop at each partition (if ";" exist) and get all the GO_ids for that partition, and keep only unique set - need to discuss with others if it is reasonable or we introduce a bias?
# 

#source("https://bioconductor.org/biocLite.R")
#biocLite("GO.db")
#biocLite("GOstats")
#biocLite("org.At.tair.db")
#biocLite("AnnotationDbi")

library(BiocGenerics)
library(AnnotationDbi) # Used for preparing GO to gene mappings
library(GO.db) # Used for retriving GO_id to GO_term assosiations
library(annotate)
library(GOstats) # for running GO Enrichment
library(GSEABase) # to create the costume GO2All mappings object for GOStats

### Functions ###

# function to parse the goframeData table to gene GO assignmet table (e.g. gene_id1\tGO_id1,GO_id2\n)
geneGO <- function(goframeData_table){
  goframeData = goframeData_table[c(3,1)] # Save only the gene_ids and GO_ids to a new dataframe
  goframeData_sorted = goframeData[order(goframeData$V3),] # order the dataframe based on the gene_ids
  geneGO_map = aggregate(V1 ~., goframeData_sorted, toString) # For each gene_id aggregate all the GO_ids with comma seperation
  return(geneGO_map)
}

# a function to retrieve all the GOids for a certain gene_id from the geneGO_map table
findGO <- function(gene_id, geneGO_map){
  if(gene_id %in% geneGO_map$V3){
    indices = grep(gene_id, geneGO_map$V3)
    GO_ids = geneGO_map$V1[indices]
    GO_ids = gsub(" ", "", GO_ids, fixed = T)
    GO_ids = unlist(strsplit(GO_ids, ","))
  } else { 
    GO_ids = "NA"
  }
  return(GO_ids)
}  

### Inputs ###

args = commandArgs(TRUE)

# read the input files and the arguments:
partition_info = read.delim(args[1], sep = "\t", header=TRUE) # Input the parse_partitionMembers.txt file (with the Model_species_identifier column)
pbs = read.csv(args[2], header=TRUE) #  Input the pbs.csv file
goframeData = read.delim(args[3], sep = "\t", header=FALSE) # Input the goframeData.txt file with three columns: GO_id, Evidence and Gene_id, for a model organism that will be used for the PBS GO enrichment analysis
node_number_to_label = read.delim(args[4], sep = "\t", header=TRUE) # Input the node_number_to_label.txt for the node labels
# Check for the pbs_cutt argument, if not specify, set it to "4":
if (length(args)>4){
  if (!is.na(as.numeric(args[5]))) {
    pbs_cutt = as.numeric(args[5]) # Set the pbs_cutt according to the user specification
  } 
  else {
    pbs_cutt = 4 # Set the default value (4) 
  }
}

# Get PhyloGeneious environment variables
oid_home_path = Sys.getenv("OID_HOME") 
oid_user_dir_path = Sys.getenv("OID_USER_DIR")

### Parse the partition and goframeData information ###

# Currently, the python script that generate parse_partitionMembers.txt allow the user to specify more than one species as a model (i.e. the Model_species_identifier column may have more than one identifier if more than one model was specified) - I need to think how to use this information for the GO annotation (maybe retrieve the GOs based on the first model, and to the partitions that didn't recieved GO annotion, try with the second identifier, etc.) - I'm currently only using the first identifier (first model specified)
partition_info$Model_species_identifier = as.character(partition_info$Model_species_identifier)
for (i in 1:length(partition_info$Model_species_identifier)) { # For partitions without model species identifier, put the PartitionID instead of "NA" so that they will still be represented in PhyloBrowse
  if (is.na(partition_info$Model_species_identifier[i])) {
    partition_info$Model_species_identifier[i]=paste("Partition",partition_info$PartitionID[i], sep="_")
  }
}  

# get a geneGO_map of all GOids assosiated with a gene_id - if more than one GOid, concatinate to a string with "," as a separator  
geneGO_map = geneGO(goframeData) # run the geneGO function created above to parse the goframeData table to geneToGo mapping association (gene_id1\tGO_id1,GO_id2\n)

#I loop on each object in the vector partition_info$Model_species_identifier to get the GOids for all the identifiers of that partition - need to make this step more efficient!
GO_id = c() # store the GO_ids in this vector (for each partition a sting with a list of GO_ids or "NA")
for (i in 1:length(partition_info$Model_species_identifier)) {
  model_id = unlist(strsplit(partition_info$Model_species_identifier[i],split=";")) # split if more than one identifier exist
  goid = c()
  for (i in 1:length(model_id)){ # can handle more than one identifier
    goid = c(goid, findGO(model_id[i],geneGO_map)) # find GO_ids for all identifiers and concatinate to one vector
    goid = unique(goid) # remove redundant GO_ids
    goid <- goid[goid != "NA"] # get rid of "NA" and put it back if there are any annotated GO_ids (if for one identifer there are GO_ids and for the other identifier(s) there are none...)
    if (length(goid) == 0){
      goid = c("NA")
    }
  }
  goid = paste(goid,collapse=",")
  GO_id = c(GO_id, goid)
}

partition_info$GO_id = GO_id # add the geneToGo info to the partition_info table

partition_info[is.na(partition_info)] = "NA" # change NA to "NA" for the partitions that miss either the model organism ortholog or its GO annotation
write.table(partition_info, sep="\t", file="partition_info.txt", quote = FALSE, row.names = FALSE, col.names = TRUE) # save partition_info

### Add partition and node information to the PBS table ###
pbs$node_id = node_number_to_label$label[match(pbs$clade,node_number_to_label$number)] # add a node label column (i.e. the "N#"), based on the get_node_labels.R script output
pbs$taxa_occupancy = partition_info$Partition_taxa_occupancy[match(pbs$partition,partition_info$PartitionID)] # add taxa occupancy
pbs$model_gene_id = partition_info$Model_species_identifier[match(pbs$partition,partition_info$PartitionID)] # add model species gene ids for each partition
pbs$GO_id = partition_info$GO_id[match(pbs$partition,partition_info$PartitionID)] # add GO_id to each partition
pbs[is.na(pbs)] = "NA" # put "NA" for missing values

# Save the pbs data frame into a file that will be used to generate the bpPBS.json file for PhyloBrowse using python. PhyloBrowse will need the clade, model_gene_id and the pbs, plus the GO enrichment results...
write.table(pbs, sep="\t", file="partition_annotation_with_all_pbs.txt", quote = FALSE, row.names = FALSE, col.names = TRUE) # save

# Filter the partitions based on the pbs threshold (default -4,4 if not specified):
pbs_filtered = subset(pbs, pbs >= pbs_cutt | pbs <= -pbs_cutt , select=c(clade, partition, pbs, node_id, taxa_occupancy, model_gene_id, GO_id))
write.table(pbs_filtered, sep="\t", file="partition_annotation_with_pbs_filtered.txt", quote = FALSE, row.names = FALSE, col.names = TRUE) # Save the pbs_filtered if will want to use it

### Run GOstats on the filtered PBS genes for each node ###
# generating a unique list of the node_ids to run GO enrichment on each node seperatly  
node = unique(pbs_filtered$node_id)

# Define the universe list
universe_Gene_list = c() # generate a list of "geneIDs" - the background for the ORA - of the model organism(s), for all partition that were included in the phylogenetic matrix, and have GO annotation
for (i in 1:length(partition_info$Model_species_identifier)) {
  if (partition_info$GO_id[i]!="NA") {
    universe_Gene_list = c(universe_Gene_list, partition_info$Model_species_identifier[i])
  }
}  

# Generate the gene2GO mapping of the universal_Gene_list for PhyloBrowse
universe_Gene_list_to_GO = data.frame(universe_Gene_list, partition_info$GO_id[match(universe_Gene_list,partition_info$Model_species_identifier)])
colnames(universe_Gene_list_to_GO) = c("Model_species_identifier", "GO_id")
universe_Gene_list_to_GO$GO_id = gsub(",", "", gsub("", "", universe_Gene_list_to_GO$GO_id)) # change the "," seperator between GO_ids to white space, as expected by PhyloBrowse...
write.table(universe_Gene_list_to_GO, sep=" | ", file="geneToGo.txt", quote = FALSE, row.names = FALSE, col.names = FALSE) # save that into a file GoDesc.txt for PhyloBrowse

# Generate a GO_id to GO_term assosiation file for PhyloBrowse
go_included = paste(universe_Gene_list_to_GO$GO_id, collapse = ' ') # this concatenate all the GO_ids af all the GO annotated partitions into one string seperated by whitespace (so now all the GO_ids are seperated by white species)
go_included = unique(as.list(strsplit(go_included, " ")[[1]])) # breake the concatenated GO_ids string into a unique GO_id list (so now every GO_id is a seperated element in the list, and represented only once (unique))
goterms = Term(GOTERM) # get all the GO_ids and their GO_Terms from the GO.db
godesc = goterms[match(go_included, names(goterms))] # match the GO_Term description to the GO_id that are in go_included
godesc = data.frame(names(godesc),godesc) # convert it to dataframe
godesc = godesc[complete.cases(godesc),] # remove cases where no match between go_included and goterms was found (removes rows with "NA")
write.table(godesc, sep=" | ", file="GoDesc.txt", quote = FALSE, col.names = FALSE, row.names = FALSE) # save that into a file GoDesc.txt for PhyloBrowse

# extract the filtered PBS genes for each node and run GO ORA:

# Preparing the GO2All mappings for GOStats
goFrame=GOFrame(goframeData)
goAllFrame=GOAllFrame(goFrame)
gsc = GeneSetCollection(goAllFrame, setType = GOCollection())

# Run GOStats for each node seperatly
for(i in node){
  node_PBS_model_gene_list = pbs_filtered$model_gene_id[pbs_filtered$node_id==i] #  - only the list of the gene model ids of partitions with pbs score above the threshold for that node
  node_PBS_model_gene_list = subset(node_PBS_model_gene_list, (!is.na(node_PBS_model_gene_list))) ## take out the partitions with "NA" gene model identifier

  params_BP = GSEAGOHyperGParams(name="My Custom GSEA based annot Params",
                geneSetCollection=gsc,
                geneIds=node_PBS_model_gene_list,
                universeGeneIds=universe_Gene_list,
                ontology="BP",
                pvalueCutoff=0.01,
                conditional=FALSE,
                testDirection="over")
  overRepresented_BP=hyperGTest(params_BP)
  BP_table = summary(overRepresented_BP)
  #write.csv(BP_table,paste(paste(i,sep="_"), "_BP_table.csv", sep=""))
  
  params_MF = GSEAGOHyperGParams(name="My Custom GSEA based annot Params",
                                 geneSetCollection=gsc,
                                 geneIds=node_PBS_model_gene_list,
                                 universeGeneIds=universe_Gene_list,
                                 ontology="MF",
                                 pvalueCutoff=0.01,
                                 conditional=FALSE,
                                 testDirection="over")
  overRepresented_MF=hyperGTest(params_MF)
  MF_table = summary(overRepresented_MF)  
  #write.csv(MF_table,paste(paste(i,sep="_"), "_MF_table.csv", sep=""))  
  
  params_CC = GSEAGOHyperGParams(name="My Custom GSEA based annot Params",
                                 geneSetCollection=gsc,
                                 geneIds=node_PBS_model_gene_list,
                                 universeGeneIds=universe_Gene_list,
                                 ontology="CC",
                                 pvalueCutoff=0.01,
                                 conditional=FALSE,
                                 testDirection="over")
  overRepresented_CC=hyperGTest(params_CC)
  CC_table = summary(overRepresented_CC)  
  #write.csv(CC_table,paste(paste(i,sep="_"), "_CC_table.csv", sep=""))  
  
  colnames(BP_table)[1] = "GOID" # need to change the GOID column name to be the same for each BP, MF and CC table in order to merge them... 
  colnames(MF_table)[1] = "GOID"
  colnames(CC_table)[1] = "GOID"
  all_enriched_terms = rbind(BP_table,MF_table,CC_table) # concatinate the BP, MF and CC enriched terms for each node
  write.csv(all_enriched_terms,paste(paste(i,sep="_"), "_all_enriched_terms_table.csv", sep=""))
}
