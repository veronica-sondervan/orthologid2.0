#!/bin/ksh
$OID_HOME/bin/setup_proc.pl $1 $2 $3
